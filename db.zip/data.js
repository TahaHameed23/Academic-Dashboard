export const noOfClasses = {
    "total_classes": 250,
    "ML": 50,
    "OOSD": 50,
    "DBMS": 50,
    "DAA": 50,
    "WT": 50
};

//TODO: make a formula to calculate attendance percentage 



