import mysql from "mysql2"

const db = mysql.createConnection({
    host: "att-db.chd3aodsweii.ap-south-1.rds.amazonaws.com",
    port: 3306,
    user: "admin",
    password: "12345678",
    database:"",
});

const conn = db.connect((err) => {
    if (err) {
        console.log(err);
    } else {
        console.log("Connected to MySQL");
    }
});

const res1 = await db.promise().query("use attend;");
const res = await db.promise().query("show tables;");
const res2 = await db.promise().query("select * from attendance;");
console.log(res);




export default conn;
